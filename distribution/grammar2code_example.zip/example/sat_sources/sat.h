void load_from_file(char *instance) {}
